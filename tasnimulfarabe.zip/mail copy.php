<?php
// Include PHPMailer classes
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$mail = new PHPMailer(true); // Create a new PHPMailer instance

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = strip_tags(trim($_POST["name"]));
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $phone = strip_tags(trim($_POST["phone"])); // This field is optional
    $message = strip_tags(trim($_POST["message"]));

    // Validate form data
    if (empty($name) || !filter_var($email, FILTER_VALIDATE_EMAIL) || empty($message)) {
        echo "Error: Please fill in all the required fields correctly.";
        exit;
    }

    try {
        // Server settings
        $mail->isSMTP();                                        // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';          // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                             // Enable SMTP authentication
        $mail->Username   = 'farabetasnimul@gmail.com';       // Your Hotmail email address
        $mail->Password   = 'jchtzmqdvfhauvje';              // Your Hotmail password or App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;   // Enable TLS encryption
        $mail->Port       = 587;                              // TCP port to connect to

        // Enable debugging
        $mail->SMTPDebug = 2; // Enable verbose debug output

        // Recipients
        $mail->setFrom('farabetasnimul@gmail.com', 'Website Contact Form'); // Sender's email and name
        $mail->addAddress('farabetasnimul@gmail.com');            // Add your email address

        // Content
        $mail->isHTML(true);                                    // Set email format to HTML
        $mail->Subject = 'New Contact Form Submission';
        $mail->Body    = "You have received a new message from your website contact form.<br><br>
                          <strong>Name:</strong> $name<br>
                          <strong>Email:</strong> $email<br>
                          <strong>Phone:</strong> $phone<br><br>
                          <strong>Message:</strong><br>$message";

        // Send the email
        $mail->send();
        header("Location: thank-you.html");  // Redirect to a thank you page
        exit;
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
} else {
    echo "Error: Invalid request method.";
}
?>